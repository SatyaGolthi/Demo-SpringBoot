package com.cg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CATEGORY")
@Getter
@Setter
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;
	
	//@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@Column(name = "PRODUCT_TYPE", nullable = false)
	private String productType;
	
	@Column(name = "NAME", nullable = false)
	private String name;

}
