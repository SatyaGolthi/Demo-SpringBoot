package com.cg.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.entities.Category;
import com.cg.demo.repositories.CategoryRepository;
import com.cg.demo.repositories.ProductRepository;

@Service
public class CategoryServiceImpl implements ICategoryService {

	/*@Autowired
	private ProductRepository prodRepo;*/
	@Autowired
	private CategoryRepository cateRepo;
	
	@Override
	public Category addCategory(Category category) {
		return cateRepo.save(category);
	}
	
	

}
