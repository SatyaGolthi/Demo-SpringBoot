package com.cg.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;






import com.cg.demo.entities.Category;
import com.cg.demo.entities.Product;
import com.cg.demo.entities.Property;
import com.cg.demo.repositories.CategoryRepository;
import com.cg.demo.repositories.ProductRepository;
import com.cg.demo.repositories.PropertyRepository;

@Service
public class ProductServcieImpl implements IProductService {

	@Autowired
	ProductRepository prodRepo;
	
	@Autowired
	CategoryRepository cateRepo;
	
	@Autowired
	PropertyRepository propRepo;

	@Override
	public Product addProduct(Product product, int id) {
		Category category=cateRepo.findOne(id);
		product.setCategory(category);
		Property property=propRepo.findOne(id);
		product.setProperty(property);
		Product newproduct=prodRepo.save(product);
		return newproduct;
	
	}

	@Override
	public Product getProductDetails(int proId) {
		
		return prodRepo.findOne(proId);
	}
	

	@Override
	public List<Product> getProducts() {
		return prodRepo.findAll();
	}

  
	@Override
	public Product updateProduct(Product product,int id) {
		
		
		Product newProduct = prodRepo.findOne(id);
		
		newProduct.setPrice(product.getPrice());
		
		return prodRepo.save(newProduct);
	}

	@Override
	public void deleteProduct(int id) {
		prodRepo.delete(id);
		
  /* @Override
	public List<Product> getByCategory(String productType) {
		
		return cateRepo.findByCategory(category);
	}*/
		

	}
	}


