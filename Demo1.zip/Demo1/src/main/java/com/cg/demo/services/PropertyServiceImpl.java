package com.cg.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.entities.Property;
import com.cg.demo.repositories.ProductRepository;
import com.cg.demo.repositories.PropertyRepository;


@Service
public class PropertyServiceImpl implements IPropertyService {


	/*@Autowired
	private ProductRepository prodRepo;*/
	
	@Autowired
	private PropertyRepository propRepo;
	
	@Override
	public Property addProperty(Property property) {
		
	return propRepo.save(property);
	}

}
