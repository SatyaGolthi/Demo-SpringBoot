package com.cg.demo.entities;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CATEGORY")
@Getter
@Setter
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int Id;
	
	//@OneToMany(mappedBy="PRODUCT_ID")
  
  @Column(name = "PRODUCT_TYPE")
	private  String productType;
	
	/* @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
	  private List<Product> products;*/
 
	@Column(name = "PRODUCT_DESCRIPTION")
	private String productDescription;
	
	
}
