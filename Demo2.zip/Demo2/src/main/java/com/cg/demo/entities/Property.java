package com.cg.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "PROPERTY")
@Getter
@Setter
public class Property {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int Id;
	
	@Column(name = "COLOUR", nullable = false)
	private String colour;
	
    
	@Column(name = "MATERIALS", nullable = false)
	private String materialsUsed;
}
