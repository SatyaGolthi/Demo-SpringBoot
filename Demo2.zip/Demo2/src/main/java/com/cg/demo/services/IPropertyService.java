package com.cg.demo.services;

import com.cg.demo.entities.Property;

public interface IPropertyService {
	
	public  Property addProperty(Property property);

}
