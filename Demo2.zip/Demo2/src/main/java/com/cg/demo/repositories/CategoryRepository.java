package com.cg.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.demo.entities.Category;
import com.cg.demo.entities.Product;

@Repository
public interface CategoryRepository extends JpaRepository<Category,Integer>{
	
	


}
