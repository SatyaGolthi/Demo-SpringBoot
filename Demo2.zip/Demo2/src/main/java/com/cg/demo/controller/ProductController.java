package com.cg.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.entities.Category;
import com.cg.demo.entities.Product;
import com.cg.demo.entities.Property;
import com.cg.demo.services.ICategoryService;
import com.cg.demo.services.IProductService;
import com.cg.demo.services.IPropertyService;


@RestController
public class ProductController {
	
	@Autowired
	IProductService productservice;
	
	@Autowired
	IPropertyService propertyservice;
	
	@Autowired
	ICategoryService categoryservice;
	
	 //............................... add category .....................................
	
	@RequestMapping(value="/category", method=RequestMethod.POST)
	 public Category addCategory(@RequestBody Category category) {
		
		return categoryservice.addCategory(category);
	}
	 //............................... add property .....................................
	
	@RequestMapping(value="/property", method=RequestMethod.POST)
	 public Property addProperty(@RequestBody Property property) {
		
		return propertyservice.addProperty(property);
	}
	
	//............................... add product.....................................
	
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product product){//, @PathVariable int id){
		
		Product pro=productservice.addProduct(product);//, id);
		return pro;
	}
	
	//............................... get productDetails by id.....................................
	
	@RequestMapping(value="/product/{id}",method=RequestMethod.GET)
	public Product getProductDetails(@PathVariable int id){
		
		return productservice.getProductDetails(id);
	}
	
	//............................... get AllproductDetails   ....................................
	
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public List<Product> getProducts(){
		
		return productservice.getProducts();
		
	}
	
	//............................... Update productDetails   ....................................
	
	
	
	@RequestMapping(value="/product/{id}",method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product,@PathVariable int id){
		
		return productservice.updateProduct(product,id);
	}
	
	//............................... Delete productDetails   ....................................
	
	@RequestMapping(value="/product/{id}",method=RequestMethod.DELETE)
	public void deleteProduct(@PathVariable int id){
		
		productservice.deleteProduct(id);
		
	/*	@RequestMapping(value="/products/{category}",method=RequestMethod.GET)
	public List<Product> getByCategory(@PathVariable String category){
		
		return productService.getByCategory(category);
		
	}
		
	}*/
	

	
		
	}
}


