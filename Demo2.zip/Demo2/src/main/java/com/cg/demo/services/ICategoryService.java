package com.cg.demo.services;

import com.cg.demo.entities.Category;

public interface ICategoryService {
	
	public Category addCategory(Category category);

}
